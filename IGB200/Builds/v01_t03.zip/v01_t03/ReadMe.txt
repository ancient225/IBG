WASD to move
Mouse to look
Escape to exit

Talk to Bob for an example of our mini game and Jenny for infomation about a QUT field